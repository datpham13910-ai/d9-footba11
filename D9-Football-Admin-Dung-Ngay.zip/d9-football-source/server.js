const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');

const ROOT = __dirname;
const BUNDLED_DATA_FILE = path.join(ROOT, 'data', 'site-data.json');
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT, 'data');
const DATA_FILE = path.join(DATA_DIR, 'site-data.json');
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'D9Admin@2026!';
const sessions = new Map();
const SESSION_TTL = 12 * 60 * 60 * 1000;
const loginAttempts = new Map();
const LOGIN_WINDOW = 10 * 60 * 1000;
const LOGIN_MAX_ATTEMPTS = 10;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.webp': 'image/webp'
};

function send(res, status, body, headers = {}) {
  res.writeHead(status, {
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'same-origin',
    'X-Frame-Options': 'SAMEORIGIN',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    ...headers
  });
  res.end(body);
}
function json(res, status, value, headers = {}) {
  send(res, status, JSON.stringify(value), { 'Content-Type': 'application/json; charset=utf-8', ...headers });
}
function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function auth(req) {
  const token = parseCookies(req).d9_session;
  if (!token) return false;
  const expires = sessions.get(token);
  if (!expires || Date.now() > expires) {
    sessions.delete(token);
    return false;
  }
  sessions.set(token, Date.now() + SESSION_TTL);
  return true;
}
function getBody(req, max = 2 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (Buffer.byteLength(data) > max) reject(new Error('Dữ liệu quá lớn'));
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}
function validData(d) {
  return d && typeof d === 'object' && d.site && d.hero && d.values && d.coach &&
    d.programs && d.gallery && Array.isArray(d.branches) && d.registration;
}
async function ensureDataFile() {
  await fsp.mkdir(DATA_DIR, { recursive: true });
  try {
    await fsp.access(DATA_FILE);
  } catch {
    const initial = await fsp.readFile(BUNDLED_DATA_FILE, 'utf8');
    await fsp.writeFile(DATA_FILE, initial, 'utf8');
  }
}
async function saveData(d) {
  const tmp = DATA_FILE + '.tmp';
  await fsp.writeFile(tmp, JSON.stringify(d, null, 2) + '\n', 'utf8');
  await fsp.rename(tmp, DATA_FILE);
}
function safeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function clientKey(req) {
  return String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').split(',')[0].trim();
}
function loginAllowed(req) {
  const key = clientKey(req);
  const now = Date.now();
  const item = loginAttempts.get(key);
  if (!item || now - item.started > LOGIN_WINDOW) {
    loginAttempts.set(key, { started: now, count: 0 });
    return true;
  }
  return item.count < LOGIN_MAX_ATTEMPTS;
}
function recordLoginFailure(req) {
  const key = clientKey(req);
  const now = Date.now();
  const item = loginAttempts.get(key);
  if (!item || now - item.started > LOGIN_WINDOW) loginAttempts.set(key, { started: now, count: 1 });
  else item.count += 1;
}
function clearLoginFailures(req) { loginAttempts.delete(clientKey(req)); }
function cookieFor(req, token, maxAge) {
  const forwardedHttps = String(req.headers['x-forwarded-proto'] || '').toLowerCase() === 'https';
  const secure = forwardedHttps ? '; Secure' : '';
  return `d9_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${secure}`;
}
async function serveStatic(req, res, pathname) {
  if (pathname === '/') pathname = '/index.html';
  if (pathname === '/admin' || pathname === '/admin/') pathname = '/admin.html';
  let file = path.normalize(path.join(ROOT, decodeURIComponent(pathname)));
  if (!file.startsWith(ROOT)) return send(res, 403, 'Forbidden');
  try {
    const stat = await fsp.stat(file);
    if (stat.isDirectory()) file = path.join(file, 'index.html');
    const content = await fsp.readFile(file);
    send(res, 200, content, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
  } catch {
    send(res, 404, '404 - Không tìm thấy trang', { 'Content-Type': 'text/plain; charset=utf-8' });
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const p = url.pathname;
  try {
    if (p === '/health' && req.method === 'GET') return json(res, 200, { ok: true });
    if (p === '/api/site-data' && req.method === 'GET') {
      const text = await fsp.readFile(DATA_FILE, 'utf8');
      return send(res, 200, text, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    }
    if (p === '/api/admin/status' && req.method === 'GET') {
      return json(res, 200, { authenticated: auth(req), configured: Boolean(ADMIN_PASSWORD) });
    }
    if (p === '/api/admin/login' && req.method === 'POST') {
      if (!ADMIN_PASSWORD) return json(res, 503, { error: 'Chưa cấu hình ADMIN_PASSWORD trên máy chủ.' });
      if (!loginAllowed(req)) return json(res, 429, { error: 'Đăng nhập sai quá nhiều lần. Hãy thử lại sau.' });
      const body = JSON.parse(await getBody(req) || '{}');
      if (!safeEqual(body.password || '', ADMIN_PASSWORD)) {
        recordLoginFailure(req);
        return json(res, 401, { error: 'Mật khẩu không đúng.' });
      }
      clearLoginFailures(req);
      const token = crypto.randomBytes(32).toString('hex');
      sessions.set(token, Date.now() + SESSION_TTL);
      return json(res, 200, { ok: true }, { 'Set-Cookie': cookieFor(req, token, SESSION_TTL / 1000) });
    }
    if (p === '/api/admin/logout' && req.method === 'POST') {
      const token = parseCookies(req).d9_session;
      if (token) sessions.delete(token);
      return json(res, 200, { ok: true }, { 'Set-Cookie': cookieFor(req, '', 0) });
    }
    if (p === '/api/admin/site-data' && req.method === 'GET') {
      if (!auth(req)) return json(res, 401, { error: 'Chưa đăng nhập.' });
      const text = await fsp.readFile(DATA_FILE, 'utf8');
      return send(res, 200, text, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    }
    if (p === '/api/admin/site-data' && req.method === 'PUT') {
      if (!auth(req)) return json(res, 401, { error: 'Phiên đăng nhập đã hết hạn.' });
      const body = JSON.parse(await getBody(req));
      if (!validData(body)) return json(res, 400, { error: 'Cấu trúc dữ liệu website không hợp lệ.' });
      await saveData(body);
      return json(res, 200, { ok: true, savedAt: new Date().toISOString() });
    }
    return serveStatic(req, res, p);
  } catch (err) {
    console.error(err);
    return json(res, 500, { error: err.message || 'Lỗi máy chủ.' });
  }
});

ensureDataFile().then(() => {
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`D9 Football Academy: http://localhost:${PORT}`);
    console.log(`Admin: http://localhost:${PORT}/admin`);
    console.log(`Data file: ${DATA_FILE}`);
    if (!ADMIN_PASSWORD) console.warn('CẢNH BÁO: Chưa đặt ADMIN_PASSWORD. Admin sẽ không thể đăng nhập.');
  });
}).catch(err => {
  console.error('Không thể khởi tạo dữ liệu:', err);
  process.exit(1);
});
