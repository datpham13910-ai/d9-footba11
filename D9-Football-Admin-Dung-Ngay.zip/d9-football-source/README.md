# D9 Football - ban de dung

Mat khau Admin mac dinh: `D9Admin@2026!`

## Chay tren may
1. Cai Node.js 18 tro len.
2. Mo Terminal/PowerShell trong thu muc nay.
3. Chay `npm start`.
4. Mo `http://localhost:3000` de xem website.
5. Mo `http://localhost:3000/admin` de quan ly.

Ban co the doi mat khau sau nay bang bien moi truong `ADMIN_PASSWORD`. Khi dua len hosting, can hosting ho tro Node.js; chi upload vao hosting tinh/Wix static thi chuc nang Luu cua Admin se khong hoat dong.
