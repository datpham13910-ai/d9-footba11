const esc = (value = '') => String(value)
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;')
  .replaceAll("'", '&#039;');

async function loadData() {
  // Ưu tiên API để thấy dữ liệu mới ngay sau khi Admin bấm Lưu.
  // Nếu deploy trên hosting tĩnh, tự động dùng file JSON dự phòng.
  let response = await fetch('/api/site-data', { cache: 'no-store' }).catch(() => null);
  if (!response || !response.ok) response = await fetch('data/site-data.json', { cache: 'no-store' });
  if (!response.ok) throw new Error('Không tải được dữ liệu website');
  return response.json();
}

function renderSite(d) {
  document.title = d.site.name;
  const nav = d.navigation.map(x => `<a href="${esc(x.href)}">${esc(x.label)}</a>`).join('');
  const valueCards = d.values.items.map(x => `
    <article class="card value-card"><div class="icon">${esc(x.icon)}</div><h3>${esc(x.title)}</h3><p>${esc(x.text)}</p></article>`).join('');
  const programs = d.programs.items.map((x,i) => `
    <article class="program-card"><span>${String(i+1).padStart(2,'0')}</span><h3>${esc(x.title)}</h3><p>${esc(x.text)}</p></article>`).join('');
  const gallery = d.gallery.images.map((src,i) => `<button class="gallery-item" data-src="${esc(src)}" aria-label="Mở ảnh ${i+1}"><img src="${esc(src)}" alt="Hoạt động D9 Football Academy ${i+1}" loading="lazy"></button>`).join('');
  const branches = d.branches.map((b,i) => `
    <article class="branch-card">
      <div class="branch-number">0${i+1}</div>
      <h3>${esc(b.name)}</h3>
      <strong>${esc(b.venue)}</strong>
      <p class="address">${esc(b.address)}</p>
      <ul>${b.schedule.map(s=>`<li>${esc(s)}</li>`).join('')}</ul>
      <div class="prices">${b.prices.map(p=>`<b>${esc(p)}</b>`).join('')}</div>
      <a class="text-link" href="#dang-ky" data-branch="${esc(b.name)}">Đăng ký ${esc(b.name)} →</a>
    </article>`).join('');

  document.querySelector('#app').innerHTML = `
    <header class="site-header">
      <a class="brand" href="#top"><img src="${esc(d.logo)}" alt="Logo D9"><div><b>D9 FOOTBALL ACADEMY</b><span>${esc(d.site.tagline)}</span></div></a>
      <nav>${nav}</nav>
      <a class="phone-pill" href="tel:${esc(d.site.phoneRaw)}">☎ ${esc(d.site.phoneDisplay)}</a>
      <button class="menu-btn" aria-label="Mở menu">☰</button>
    </header>

    <main id="top">
      <section class="hero" style="--hero:url('${esc(d.hero.image)}')">
        <div class="hero-overlay"></div>
        <div class="hero-copy container">
          <p class="eyebrow">${esc(d.hero.eyebrow)}</p>
          <h1>${esc(d.hero.title)}</h1>
          <p class="hero-sub">${esc(d.hero.subtitle)}</p>
          <div class="hero-actions"><a class="btn primary" href="#dang-ky">Đăng ký học thử</a><a class="btn ghost" href="#lich-tap">Xem lịch tập & học phí</a></div>
          <div class="badges">${d.hero.badges.map(x=>`<span>⚽ ${esc(x)}</span>`).join('')}</div>
        </div>
      </section>

      <section id="gioi-thieu" class="section light">
        <div class="container section-head"><p class="eyebrow dark">${esc(d.values.eyebrow)}</p><h2>${esc(d.values.title)}</h2><p>${esc(d.values.description)}</p></div>
        <div class="container grid four">${valueCards}</div>
      </section>

      <section id="hlv" class="section coach-section">
        <div class="container coach-grid">
          <div class="coach-image"><img src="${esc(d.coach.image)}" alt="${esc(d.coach.name)}"></div>
          <div class="coach-copy"><p class="eyebrow">${esc(d.coach.eyebrow)}</p><h2>${esc(d.coach.name)}</h2><p>${esc(d.coach.bio)}</p><blockquote>“${esc(d.coach.quote)}”</blockquote><a class="btn primary" href="tel:${esc(d.site.phoneRaw)}">Liên hệ HLV Đạt</a></div>
        </div>
      </section>

      <section id="chuong-trinh" class="section dark-section">
        <div class="container section-head left"><p class="eyebrow">${esc(d.programs.eyebrow)}</p><h2>${esc(d.programs.title)}</h2></div>
        <div class="container grid four program-grid">${programs}</div>
      </section>

      <section id="hinh-anh" class="section light">
        <div class="container section-head"><p class="eyebrow dark">${esc(d.gallery.eyebrow)}</p><h2>${esc(d.gallery.title)}</h2><p>${esc(d.gallery.subtitle)}</p></div>
        <div class="container gallery">${gallery}</div>
      </section>

      <section id="lich-tap" class="section schedule-section">
        <div class="container section-head"><p class="eyebrow">LỊCH TẬP & HỌC PHÍ</p><h2>3 cơ sở đào tạo D9 Football Academy</h2></div>
        <div class="container grid three">${branches}</div>
        <p class="uniform">${esc(d.uniformPrice)}</p>
      </section>

      <section id="dang-ky" class="section register-section">
        <div class="container register-grid">
          <div>
            <p class="eyebrow dark">ĐĂNG KÝ NGAY</p><h2>${esc(d.registration.title)}</h2><p>${esc(d.registration.description)}</p>
            <form id="registerForm" class="register-form">
              <label>Họ tên phụ huynh<input name="parentName" required></label>
              <label>Số điện thoại<input name="phone" inputmode="tel" required></label>
              <label>Tên học viên<input name="studentName" required></label>
              <label>Năm sinh<input name="birthYear" inputmode="numeric"></label>
              <label>Cơ sở muốn học<select name="branch" required><option value="">Chọn cơ sở</option>${d.branches.map(b=>`<option>${esc(b.name)}</option>`).join('')}</select></label>
              <label>Khung giờ<input name="time" placeholder="Ví dụ: Thứ 7 sáng"></label>
              <label class="full">Ghi chú<textarea name="note" rows="4"></textarea></label>
              <button class="btn primary full" type="submit">Gửi đăng ký</button>
            </form>
          </div>
          <aside class="qr-card"><img src="${esc(d.registration.qrImage)}" alt="QR đăng ký D9"><h3>Quét mã QR để đăng ký nhanh qua Zalo</h3><a href="tel:${esc(d.site.phoneRaw)}">☎ ${esc(d.site.phoneDisplay)} (${esc(d.site.contactName)})</a></aside>
        </div>
      </section>
    </main>

    <footer><div class="container footer-grid"><div class="footer-brand"><img src="${esc(d.logo)}" alt="Logo D9"><div><h3>${esc(d.site.name)}</h3><p>${esc(d.site.tagline)}</p></div></div><div><b>Liên kết nhanh</b><div class="footer-links">${nav}</div></div><div><b>Liên hệ</b><p>${esc(d.site.phoneDisplay)} (${esc(d.site.contactName)})</p><p>${esc(d.site.city)}</p></div></div><div class="copyright">© 2026 D9 Football Academy. All rights reserved.</div></footer>
    <a class="floating-call" href="tel:${esc(d.site.phoneRaw)}">☎ GỌI HLV ĐẠT</a>
    <div class="lightbox" hidden><button aria-label="Đóng">×</button><img alt="Ảnh D9 Football Academy"></div>
  `;

  const header = document.querySelector('.site-header');
  const menu = document.querySelector('.menu-btn');
  menu.addEventListener('click', () => header.classList.toggle('menu-open'));
  document.querySelectorAll('nav a').forEach(a => a.addEventListener('click',()=>header.classList.remove('menu-open')));

  document.querySelectorAll('[data-branch]').forEach(a => a.addEventListener('click', () => {
    const select = document.querySelector('[name="branch"]');
    if(select) select.value = a.dataset.branch;
  }));

  document.querySelector('#registerForm').addEventListener('submit', e => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const msg = [
      'ĐĂNG KÝ HỌC THỬ D9 FOOTBALL ACADEMY',
      `Phụ huynh: ${f.get('parentName')}`,
      `SĐT: ${f.get('phone')}`,
      `Học viên: ${f.get('studentName')}`,
      `Năm sinh: ${f.get('birthYear') || ''}`,
      `Cơ sở: ${f.get('branch')}`,
      `Khung giờ: ${f.get('time') || ''}`,
      `Ghi chú: ${f.get('note') || ''}`
    ].join('\n');
    window.location.href = `sms:${d.site.phoneRaw}?body=${encodeURIComponent(msg)}`;
  });

  const lightbox = document.querySelector('.lightbox');
  const lbImg = lightbox.querySelector('img');
  document.querySelectorAll('.gallery-item').forEach(btn => btn.addEventListener('click', () => { lbImg.src = btn.dataset.src; lightbox.hidden = false; document.body.classList.add('no-scroll'); }));
  const close = () => { lightbox.hidden = true; lbImg.src=''; document.body.classList.remove('no-scroll'); };
  lightbox.querySelector('button').addEventListener('click', close);
  lightbox.addEventListener('click', e => { if(e.target===lightbox) close(); });
}

loadData().then(renderSite).catch(err => {
  document.querySelector('#app').innerHTML = `<div style="padding:40px;font-family:sans-serif"><h1>Không tải được dữ liệu website</h1><p>${esc(err.message)}</p><p>Hãy chạy website qua máy chủ local (ví dụ: <code>python -m http.server</code>), không mở trực tiếp bằng file://.</p></div>`;
});
